
filelist =['cdk2_feats.txt','akt2_feats.txt','boPKACA_feats.txt','phkg1_feats.txt','dyrk1a_feats.txt','mark2_feats.txt','akt1_feats.txt','musPKACA_feats.txt','pak4_feats.txt',
'hPKACA_feats.txt','cdk2_negfeats.txt','akt2_negfeats.txt','boPKACA_negfeats.txt','phkg1_negfeats.txt','dyrk1a_negfeats.txt',
'mark2_negfeats.txt','akt1_negfeats.txt','musPKACA_negfeats.txt','pak4_negfeats.txt','hPKACA_negfeats.txt']

with (open('eukSTPKs_aacompfeats.txt','w')) as outputfile:

	for filename in filelist:
		subsfile = open(filename,'rb')
		for line in subsfile.readlines():	
			splitline = line.strip('\n')
			outputfile.write(line)
		subsfile.close()

