
filelist =['pknA_feats.txt','pknB_feats.txt','pknD_feats.txt','pknE_feats.txt','pknF_feats.txt','pknG_feats.txt','pknH_feats.txt','pknJ_feats.txt','pknK_feats.txt','pknL_feats.txt',
'pknA_negfeats.txt','pknB_negfeats.txt','pknD_negfeats.txt','pknE_negfeats.txt','pknF_negfeats.txt','pknG_negfeats.txt','pknH_negfeats.txt','pknJ_negfeats.txt','pknK_negfeats.txt','pknL_negfeats.txt']

with (open('mtbSTPKs_aacompfeats.txt','w')) as outputfile:

	for filename in filelist:
		subsfile = open(filename,'rb')
		for line in subsfile.readlines():	
			splitline = line.strip('\n')
			outputfile.write(line)
		subsfile.close()

