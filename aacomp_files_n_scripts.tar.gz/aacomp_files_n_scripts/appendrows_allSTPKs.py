
filelist =['eukSTPKs_aacompfeats.txt', 'mtbSTPKs_aacompfeats.txt']

with (open('allSTPKs_aacompfeats.txt','w')) as outputfile:

	for filename in filelist:
		subsfile = open(filename,'rb')
		for line in subsfile.readlines():	
			splitline = line.strip('\n')
			outputfile.write(line)
		subsfile.close()

