import os, glob
import numpy as np

dir_files = [f for f in os.listdir('.') if os.path.isfile(f)]			# files variable holds the current directory
for f in dir_files:	
	if f.endswith('.dis'):
		outfile = f.split(".")[0] + "_avgIDRs.txt"
		c = open(f, 'r')  
		idr_file = c.readlines()
		diso_window_avgs = []						# list to hold average IDR values for all 7-residues windows of input file 

		diso_vals_list = []
		for l in idr_file:
			if not l.startswith('#'): 				# if row is not file headers
				line_stuff = l.strip('\n').split(' ')
				res_info_list = [] 				# list holds amino acid residue's number, its single letter code and intrinsic disorder (IDR) value
				for i in range(0, len(line_stuff)):
					if line_stuff[i] != (''):		# if line element is not empty (whitespace/s), add the element to the 'res_info_list'
						res_info_list.append(line_stuff[i])	
				diso_vals_list.append(res_info_list[2])		# res_info_list's 3rd element i.e. IDR value is added to 'diso_vals_list'

		for j in range (3, len(diso_vals_list)-3):		# 3 and -3 offsets to derive 7 residues averaged IDR for only the residues with 3 residues upstream and downstream
			diso_win_sum = 0 					# sum of the IDR values for a 7-residues window	
			diso_win_avg = 0					# average of the IDR for a 7-residues window
			for i in range(j-3, j+4):				# adds IDR values of the current window e.g. from list index 0(j-3) to 6(j+4) 
				diso_win_sum += float(diso_vals_list[i])	# sum of IDR values of a window

			diso_win_avg = float(diso_win_sum/7)			# average IDR of the window
			diso_window_avgs.append(float(diso_win_avg))

		with open(outfile, "wb" ) as fp:
			for i in range(0, len(diso_window_avgs)):	
				fp.write(str(i+1))				# window's starting residue number
				fp.write('\t')
				fp.write(str(i+7))				# window's ending residue number
				fp.write('\t')		
				fp.write(str(diso_window_avgs[i]))
				fp.write('\t')
				fp.write(str(i+4))				# the central residue's number to which the average IDR value is assigned
				fp.write('\n') 
c.close()
